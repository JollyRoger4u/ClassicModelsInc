<!doctype html>

<html lang="en">

<?php
include'header.php';
?>
    <div>
        <form action="includes/login.php" method="post">
            <label>Username</label>
            <input type="text" label="Username" name="mailid" placeholder="username or email">
            <br>
            <label>Password</label>
            <input type="password" name="pw" placeholder="enter your password">
            <br>
            <button type="submit" name="logInBtn">Let me in!</button>
        </form>
        <a href="register.php">Register</a>
        <form action="includes/logout.php" method="post">
            <button type="submit" name="logOutBtn">Logout</button>
        </form>
    </div>

    <!--<script src="js/scripts.js"></script>-->
<?php include'footer.php' ?>

</html>