<footer>


<p>this is the footer</p>

</footer>

</body>
</html>