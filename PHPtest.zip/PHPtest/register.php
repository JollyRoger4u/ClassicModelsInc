<head>
    <link rel="stylesheet" type="text/css" href="../css/logIn.css">
</head>
<?php

 
require_once ('header.php');
try {
 
    $conec = new Dbconnect();
    $con   = $conec->DatabaseConnect();
    if ($con) {
        $sql = "INSERT INTO `users`(`username`) VALUES ('behmed')";
        $re  = $con->query($sql);
    } else {
        echo $con;
    }
} catch (PDOException $ex) {
    echo $ex->getMessage();
}
 ?>
 <!DOCTYPE html>
 <html>
     <head>
         <meta charset="UTF-8">
         <title>Register</title>
     </head>
     <body>
     <section id="logInSection">
      <form method="post" action="login.php">
        <ul class="wrapper">
          <li class="form-row">
            <label for="userName">Username:</label>
            <input type="text" id="userName" name="userName">
          </li>
          <li class="form-row">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password">
          </li>
          <li class="form-row">
            <label for="repassword">Retype password:</label>
            <input type="password" id="repassword" name="repassword">
          </li>
          <li class="form-row">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email">
          </li>
          <li class="form-row">
            <button type="submit" name="submit">Submit</button>
          </li>
        </ul>
      </form>
      </section>
      <?php include('footer.php') ?>
      