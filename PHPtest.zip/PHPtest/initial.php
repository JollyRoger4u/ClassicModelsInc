<?php

session_start();
spl_autoload_register(function($classname) {
    if (file_exists("{$classname}.php")){
        require_once "{$classname}.php";
        return;

    }
});
?>