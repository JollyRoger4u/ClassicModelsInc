
<?php
require_once("../users/header.php");
require_once("../users/dbconnect.php");

try{
 
    $conec = new Dbconnect();
    $con = $conec->DatabaseConnect();
    if($con){
        echo 'connected';
    }
    else{
        echo $con;
    }
}
catch(PDOException $ex){
    echo $ex->getMessage();
}

?>