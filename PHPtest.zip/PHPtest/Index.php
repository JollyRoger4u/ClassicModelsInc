<html>

<?PHP
include ("header.php");
?>
<div>
    <p>Bladibla, blabloooba</p>
</div>
<?php
require 'footer.php';

?>
</html>