<?php 

require_once 'dbconnect.php';
Class UserLogin{

    private $db;

    public function __construct(){
        $this -> db = new DbConnect();
        $this -> db = $this->db->DatabaseConnect();
    }

    public function UserLogIn($userName, $userPass){
        if(!empty($userName) && !empty($userPass)){
            $stmt = $this->db->prepare("select * from customers where loginName=? and password=?");   
            $stmt -> bindParam(1, $userName);
            $stmt -> bindParam(2, $userPass);
            $stmt -> execute();
            $result = $stmt->fetch();
            echo $result['loginName'] . $result['password'];
            echo $userName . $userPass;

        if ($result['loginName'] == $userName && $result['password'] == $userPass ){
            $userObj = $stmt->fetch();
            echo "Correct login, ACCESS GRANTED";
            echo "welcome" . $userObj['firstName'];
            $_SESSION['sessionID'] = $result['userID'];
            echo $_SESSION['sessionID'];
        }else{
            echo "Incorrect username or password";
        }
    }else{
        echo "enter username and password plixx";
    }

}
public function logout(){
    session_destroy();
}
}

Class editProfile{
    private $db;

    public function __construct(){
        $this -> db = new DbConnect();
        $this -> db = $this->db->DatabaseConnect();
    }
    public function editProfileData($userName, $userPass){
        if(!empty($userName) && !empty($userPass)){
            $stmt = $this->db->prepare("select * from customers where loginName=? and password=?");   
            $stmt -> bindParam(1, $userName);
            $stmt -> bindParam(2, $userPass);
            $stmt -> execute();
            $result = $stmt->fetch();
            echo $result['loginName'] . $result['password'];
            echo $userName . $userPass;

        if ($result['loginName'] == $userName && $result['password'] == $userPass ){
            $userObj = $stmt->fetch();
            echo "Correct login, ACCESS GRANTED";
            echo "welcome" . $userObj['firstName'];
            $_SESSION['sessionID'] = $result['userID'];
            echo $_SESSION['sessionID'];
        }else{
            echo "Incorrect username or password";
        }
    }else{
        echo "enter username and password plixx";
    }

}
}

/*
class User {

    //properties

    public $user = ['customerNumber' => '0', 'userName' => 'something', 'password' => 'Not Set', 'email' => 'not set', 'hash' => 'not set', 'salt' => 'not set'];

    //methods

    public function get_user() {
        $pdo = connect_admin();
        $custID = $_SESSION['sessionID'];
        $sql = "SELECT * FROM customers
                WHERE customerNumber = '" . $this->{"customerNumber"} . "'"; // sql statements

        $toGet = $pdo->prepare($sql); // prepared statement
        $toGet->execute(); // execute sql statment

        return $toGet;

    }

    public function create_product() {
        $pdo = connect_admin();

        $sql = "INSERT INTO products (productCode, productName, productLine, productScale, productVendor, productDescription, quantityInStock, buyPrice, MSRP)
                VALUES ('" . $this->{"productCode"} . "', '" . $this->{"productName"} . "', '" . $this->{"productLine"} . "', '" . $this->{"productScale"} . "', '" . $this->{"productVendor"} . "', '" . $this->{"productDescription"} . "', '" . $this->{"quantityInStock"} . "', '" . $this->{"buyPrice"} . "', '" . $this->{"MSRP"} . "')"; // sql statement

        $toCreate = $pdo->prepare($sql); // prepared statement
        $return = $toCreate->execute(); // execute sql statment

        return $return;
    }
    
    public function update_product() {
        $pdo = connect_admin();

        $sql = "UPDATE products
                SET productName = '" . $this->{"productName"} . "', productLine = '" . $this->{"productLine"} . "', productScale = '" . $this->{"productScale"} . "', productVendor = '" . $this->{"productVendor"} . "', productDescription = '" . $this->{"productDescription"} . "', quantityInStock = '" . $this->{"quantityInStock"} . "', buyPrice = '" . $this->{"buyPrice"} . "', MSRP = '" . $this->{"MSRP"} . "'
                WHERE productCode = '" . $this->{"productCode"} . "'"; // sql statementS

        $toSave = $pdo->prepare($sql); // prepared statement
        $return = $toSave->execute(); // execute sql statment

        return $return;
    }
    
    public function delete_admin() {
        $pdo = connect_admin();

        $sql = "DELETE FROM products
                WHERE productCode = '" . $this->{"productCode"} . "'"; // sql statementS

        $toDelete = $pdo->prepare($sql); // prepared statement
        $return = $toDelete->execute(); // execute sql statment

        return $return;
    }
}
*/

?>