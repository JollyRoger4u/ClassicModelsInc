
<?php
$mysqli = new mysqli("localhost", "username", "password", "dbname");
?>
