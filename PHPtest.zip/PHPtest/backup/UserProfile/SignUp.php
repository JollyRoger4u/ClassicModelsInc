<main>
    <div>
        <form action="includes/login.php" method="post">
            <input type="text" name="mailid" placeholder="username or email">
            <input type="password" name="pw" placeholder="enter your password">
            <button type="submit" name="logInBtn">Let me in!</button>
        </form>
        <a href="register.php">Register</a>
        <form action="includes/logout.php" method="post">
            <button type="submit" name="logOutBtn">Logout</button>
        </form>
    </div>

    <!--<script src="js/scripts.js"></script>-->
</main>
