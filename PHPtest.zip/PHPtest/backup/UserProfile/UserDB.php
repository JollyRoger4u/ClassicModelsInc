<?php

class userDB{
    Private static $_DBinstance = null;
    private $_pdo, 
            $_query,
            $_error = false,
            $_results,
            $_count = 0;

}
?>