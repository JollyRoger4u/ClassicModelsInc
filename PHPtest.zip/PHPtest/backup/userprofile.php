<?php

class Apa {
    function apekatt() {
        $this->apmonster = 'King Kong';
    }
}

$grrr = new Apa();
echo $grr->apmonster;




class Car {
    function Car() {
        $this->model = "VW";
    }
}

// create an object
$herbie = new Car();

// show object properties
echo $herbie->model;


?>