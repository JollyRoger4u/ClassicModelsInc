let counter = 0;

function subtract(){
  counter = counter-1;
  document.getElementById("noOfItems").innerHTML = counter;
}

function add(){
  counter = counter + 1;
  document.getElementById("noOfItems").innerHTML = counter;
}

